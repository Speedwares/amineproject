import React ,{Component} from 'react';
import ReactTableComponent from './components/ReactTableComponent.js';




class App extends Component {


  render(){
  return (
    <div className="App">
      <ReactTableComponent />
    </div>
  );
}
}

export default App;
